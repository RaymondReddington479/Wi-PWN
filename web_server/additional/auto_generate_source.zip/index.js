process.stdout.write('\033c');

var fs = require('fs'),
    chalk = require('chalk'),
    htmlMinify = require('html-minifier').minify,
    crypto = require('crypto'),
    UglifyJS = require("uglify-js"),
    execSync = require('child_process').execSync,
    csso = require('csso'),
    replace = require("replace"),
    rimraf = require('rimraf'),
    extension,
    data = '',
    file,
    combined,
    jsStatus,
    htmlStatus,
    JSresult,
    dir = './output/';

console.log(chalk.cyanBright(' ____      ____  _ ') + chalk.cyan('       _______  ____      ____  ____  _____  \n') + chalk.cyanBright('|_  _|    |_  _|(_)') + chalk.cyan('      |_   __ \\|_  _|    |_  _||_   \\|_   _| \n') + chalk.cyanBright('  \\ \\  /\\  / /  __  ______ ') + chalk.cyan('| |__) | \\ \\  /\\  / /    |   \\ | |   \n') + chalk.cyanBright('   \\ \\/  \\/ /  [  ||______|') + chalk.cyan('|  ___/   \\ \\/  \\/ /     | |\\ \\| |   \n') + chalk.cyanBright('    \\  /\\  /    | |') + chalk.cyan('       _| |_       \\  /\\  /     _| |_\\   |_  \n') + chalk.cyanBright('     \\/  \\/    [___]') + chalk.cyan('     |_____|       \\/  \\/     |_____|\\____| '))
console.log(chalk.cyanBright('\n     Wi-PWN array generator (C) Sam Denty ') + chalk.redBright('https://samdd.me\n\n'));

if (fs.existsSync(dir)) rimraf.sync(dir);
rimraf.sync("./html/Gemfile.lock");
fs.mkdirSync(dir)
fs.mkdirSync(dir + "array")
fs.mkdirSync(dir + "gzip")

console.log(chalk.redBright('Building site...\n'));
execSync('set JEKYLL_ENV=binary && jekyll build', {cwd: './html'});

console.log(chalk.redBright('Generating arrays...\n'));

function byte(file) {
    fs.writeFileSync(dir + "gzip/" + filename + "." + extension, file);
    code = execSync('"additional/gzip.exe" -9 -f "' + dir + 'gzip/' + filename + '.' + extension + '"');
    process.stdout.write(chalk.cyanBright(" - gzipped"));

    code = execSync('"additional/bin2hex.exe" --s , --i "' + dir + 'gzip/' + filename + '.' + extension + '.gz" --o "' + dir + 'array/' + filename + '.' + extension + '.gz.array"');

    file = fs.readFileSync(dir + "array/" + filename + "." + extension + ".gz.array").toString();

    combined = "const char data_" + filename + "_" + extension + "[] PROGMEM = {" + file.replace(/(\r\n|\n|\r)/gm,"") + "};";
    return combined;
}

fs.readdir(dir + 'html', function(err, items) {
    for (var i = 0; i < items.length; i++) {
        extension = items[i].split('.').pop().toUpperCase();
        filename = items[i].split('.')[0].toLowerCase();
        if (extension == "HTML") {
            var spacing = 20 - items[i].length;
            process.stdout.write(items[i] + Array(spacing).join(" "));
            file = fs.readFileSync(dir + '/html/' + items[i], "utf8");
            file = htmlMinify(file, { collapseBooleanAttributes: !0, collapseWhitespace: !0, html5: !0, minifyCSS: !0, minifyJS: !0, processConditionalComments: !0, removeAttributeQuotes: !0, removeComments: !0, removeEmptyAttributes: !0, removeOptionalTags: !0, removeRedundantAttributes: !0, removeScriptTypeAttributes: !0, removeStyleLinkTypeAttributes: !0, removeTagWhitespace: !0, sortAttributes: !0, sortClassName: !0, trimCustomFragments: !0, useShortDoctype: !0 });
            process.stdout.write(chalk.yellowBright(" - minified"));
            data += byte(file) + '\n';
            process.stdout.write(chalk.greenBright(" - complete!\n"));
        } else if (extension == "CSS") {
            var spacing = 20 - items[i].length;
            process.stdout.write(items[i] + Array(spacing).join(" "));
            file = fs.readFileSync(dir + '/html/' + items[i], "utf8");
            file = csso.minify(file).css;
            process.stdout.write(chalk.yellowBright(" - minified"));
            data += byte(file) + '\n';
            process.stdout.write(chalk.greenBright(" - complete!\n"));
        }
    }
    htmlStatus = true;
});
fs.readdir(dir + '/html/js', function(err, items) {
    for (var i = 0; i < items.length; i++) {
        extension = items[i].split('.').pop().toUpperCase();
        filename = items[i].split('.')[0].toLowerCase();
        if (extension == "JS") {
            var spacing = 20 - items[i].length;
            process.stdout.write(items[i] + Array(spacing).join(" "));
            file = fs.readFileSync(dir + '/html/js/' + items[i], "utf8");
            JSresult = UglifyJS.minify(file);
            process.stdout.write(chalk.yellowBright(" - minified"));
            data += byte(JSresult.code) + '\n';
            process.stdout.write(chalk.greenBright(" - complete!\n"));
        }
    }
    jsStatus = true;
});

var interval = setInterval(function() {
    if (htmlStatus == true && jsStatus == true) {
        clearInterval(interval);
        console.log('Replacing arrays...');
        data = "/*auto_generator*/\n" + data + "/*end_auto_generator*/";
        replace({
            regex: "\\\/\\*auto\\_generator\\*\\\/[\\s\\S]*\\\/\\*end\\_auto\\_generator\\*\\\/",
            replacement: data,
            paths: ['../arduino/Wi-PWN/data.h'],
            recursive: true,
            silent: true,
        });
        console.log(chalk.greenBright('\n----------------------------------------------------\n') + chalk.yellowBright("MD5 hash: ") + chalk.yellow(crypto.createHash('md5').update(data).digest("hex")) + chalk.greenBright('\n----------------------------------------------------\n               Wrote arrays to data.h!'), chalk.redBright('\n\nPress any key to exit'));
        process.stdin.setRawMode(true);
        process.stdin.resume();
        process.exit();
    }
}, 1000);
